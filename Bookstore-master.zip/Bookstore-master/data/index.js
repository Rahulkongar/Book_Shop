const searchData = require('./store/search');
const userData = require('./users/user');

module.exports = {
    search: searchData,
    users: userData
}